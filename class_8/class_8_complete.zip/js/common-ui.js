$(function(){
    $(".section.visual .slider").bxSlider({
        pager:false
    });
});